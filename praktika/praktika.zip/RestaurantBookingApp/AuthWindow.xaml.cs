using System.Windows;
using System.Windows.Controls;
using RestaurantBookingApp.ViewModels;

namespace RestaurantBookingApp;

public partial class AuthWindow : Window
{
    private readonly AuthViewModel _viewModel;
    public Models.UserProfile? AuthenticatedProfile { get; private set; }

    public AuthWindow()
    {
        InitializeComponent();
        _viewModel = new AuthViewModel();
        _viewModel.Authenticated += OnAuthenticated;
        DataContext = _viewModel;
    }

    private void PasswordBox_OnPasswordChanged(object sender, RoutedEventArgs e)
    {
        if (DataContext is AuthViewModel vm && sender is PasswordBox pb)
        {
            vm.Password = pb.Password;
        }
    }

    private void OnAuthenticated(Models.UserProfile profile)
    {
        DialogResult = true;
        AuthenticatedProfile = profile;
        Close();
    }
}

