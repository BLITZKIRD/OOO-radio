using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using RestaurantBookingApp.Models;

namespace RestaurantBookingApp.Services
{
    /// <summary>
    /// Простая служба-заглушка, генерирующая демо-данные без БД.
    /// </summary>
    public static class DummyDataService
    {
        /// <summary>
        /// Возвращает готовые рестораны со столиками, меню и отзывами.
        /// </summary>
        public static ObservableCollection<Restaurant> BuildRestaurants()
        {
            var roma = new Restaurant
            {
                Name = "Roma Nuova",
                Cuisine = "Итальянская",
                Location = "Центр",
                AverageCheckTier = "Высокий",
                Rating = 4.8,
                Contacts = "+7 (495) 111-22-33",
                Description = "Авторская итальянская кухня, камин, винный бар.",
                Features = new List<string> { "Живая музыка", "Винная карта", "Парковка", "Wi-Fi" },
                Gallery = new List<string> { "Assets/roma1.jpg", "Assets/roma2.jpg" },
                WorkingHours = "Пн-Вс 11:00-01:00"
            };

            roma.Tables = BuildTables();
            roma.Menu = new ObservableCollection<MenuItem>
            {
                new() { Name = "Тальятелле с трюфелем", Category = "Паста", Price = 1250m, RequiresPreOrder = true },
                new() { Name = "Буррата с томатами", Category = "Закуски", Price = 890m, IsVegan = false },
                new() { Name = "Лимончелло спритц", Category = "Напитки", Price = 520m }
            };
            roma.Reviews = new ObservableCollection<Review>
            {
                new() { Author = "Анна", Score = 5, Comment = "Идеально для годовщины.", Date = DateTime.Today.AddDays(-2) },
                new() { Author = "Максим", Score = 4.5, Comment = "Отличная карта вин.", Date = DateTime.Today.AddDays(-10) }
            };

            var sakura = new Restaurant
            {
                Name = "Sakura Sky",
                Cuisine = "Японская",
                Location = "Москва-Сити",
                AverageCheckTier = "Высокий",
                Rating = 4.6,
                Contacts = "+7 (495) 222-44-55",
                Description = "Панорамные окна, омакесе-бар и авторские коктейли.",
                Features = new List<string> { "Панорамный вид", "Веган меню", "Терраса" },
                Gallery = new List<string> { "Assets/sakura1.jpg" },
                WorkingHours = "Пн-Вс 12:00-00:00"
            };

            sakura.Tables = BuildTables(isTerraceAvailable: true);
            sakura.Menu = new ObservableCollection<MenuItem>
            {
                new() { Name = "Сет омакесе", Category = "Сеты", Price = 3200m, RequiresPreOrder = true },
                new() { Name = "Ролл веган-дайкон", Category = "Роллы", Price = 780m, IsVegan = true },
                new() { Name = "Матча латте", Category = "Напитки", Price = 420m }
            };
            sakura.Reviews = new ObservableCollection<Review>
            {
                new() { Author = "Юля", Score = 4.8, Comment = "Восторг от вида!", Date = DateTime.Today.AddDays(-5) }
            };

            var burger = new Restaurant
            {
                Name = "Urban Burger",
                Cuisine = "Авторские бургеры",
                Location = "Марьина роща",
                AverageCheckTier = "Средний",
                Rating = 4.3,
                Contacts = "+7 (495) 333-66-77",
                Description = "Семейный формат с детской комнатой и настолками.",
                Features = new List<string> { "Детская комната", "Парковка", "Доставка" },
                Gallery = new List<string> { "Assets/burger1.jpg" },
                WorkingHours = "Пн-Вс 10:00-23:00"
            };

            burger.Tables = BuildTables(includeVip: false);
            burger.Menu = new ObservableCollection<MenuItem>
            {
                new() { Name = "BBQ бургер", Category = "Бургеры", Price = 590m },
                new() { Name = "Картофельные вафли", Category = "Закуски", Price = 310m, IsVegan = true },
                new() { Name = "Милкшейк с карамелью", Category = "Десерты", Price = 270m }
            };
            burger.Reviews = new ObservableCollection<Review>
            {
                new() { Author = "Сергей", Score = 4.2, Comment = "Очень удобно с детьми.", Date = DateTime.Today.AddDays(-1) }
            };

            return new ObservableCollection<Restaurant> { roma, sakura, burger };
        }

        /// <summary>
        /// Создаёт демонстрационные брони для клиента и администратора.
        /// </summary>
        public static ObservableCollection<Booking> BuildBookings(IList<Restaurant> restaurants)
        {
            return new ObservableCollection<Booking>
            {
                new()
                {
                    Restaurant = restaurants[0],
                    Table = restaurants[0].Tables[2],
                    Guests = 2,
                    VisitDate = DateTime.Today.AddDays(1).AddHours(19),
                    Status = "Ожидает подтверждения",
                    SpecialRequest = "Годовщина свадьбы, нужны свечи",
                    AwaitingClientConfirmation = false,
                    DepositPaid = true,
                    HasPreOrder = true
                },
                new()
                {
                    Restaurant = restaurants[1],
                    Table = restaurants[1].Tables[4],
                    Guests = 4,
                    VisitDate = DateTime.Today.AddDays(-7).AddHours(20),
                    Status = "Завершена",
                    SpecialRequest = "Аллергия на арахис",
                    AwaitingClientConfirmation = false,
                    DepositPaid = false,
                    HasPreOrder = false
                }
            };
        }

        /// <summary>
        /// Возвращает готовые награды программы лояльности.
        /// </summary>
        public static ObservableCollection<LoyaltyReward> BuildRewards()
        {
            return new ObservableCollection<LoyaltyReward>
            {
                new() { Title = "5-я бронь", Description = "Бокал просекко в подарок", Progress = 3, Threshold = 5, Partner = "Roma Nuova" },
                new() { Title = "День рождения", Description = "Скидка 20% в любимых ресторанах", Progress = 1, Threshold = 1, Partner = "Все партнёры" },
                new() { Title = "Приведи друга", Description = "500 бонусов за каждого приглашённого", Progress = 0, Threshold = 1, Partner = "Urban Burger" }
            };
        }

        private static ObservableCollection<TableSeat> BuildTables(bool includeVip = true, bool isTerraceAvailable = false)
        {
            var seats = new ObservableCollection<TableSeat>();

            for (var i = 1; i <= 12; i++)
            {
                seats.Add(new TableSeat
                {
                    Number = i,
                    Capacity = i % 4 == 0 ? 6 : 4,
                    Type = GetType(i, includeVip, isTerraceAvailable),
                    IsAvailable = i % 3 != 0,
                    RequiresDeposit = i % 5 == 0
                });
            }

            return seats;
        }

        private static string GetType(int index, bool includeVip, bool terrace)
        {
            if (includeVip && index > 10)
            {
                return "VIP-зал";
            }

            if (terrace && index <= 2)
            {
                return "Терраса";
            }

            return index % 2 == 0 ? "У окна" : "Основной зал";
        }
    }
}

