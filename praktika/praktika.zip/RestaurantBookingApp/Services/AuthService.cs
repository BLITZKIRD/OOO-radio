using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using RestaurantBookingApp.Models;
using RestaurantBookingApp.Utilities;

namespace RestaurantBookingApp.Services
{
    /// <summary>
    /// Сервис регистрации и авторизации в локальном json-хранилище.
    /// </summary>
    public class AuthService
    {
        internal const string AdminEmail = "admin@gmail.com";
        private const string AdminPassword = "admin";

        private readonly string _storePath;
        private readonly List<UserAccount> _accounts = new();

        public AuthService()
        {
            _storePath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "NeoReserve",
                "users.json");
            Directory.CreateDirectory(Path.GetDirectoryName(_storePath)!);
            Load();
            EnsureAdminAccount();
        }

        public UserAccount Register(string email, string password, string fullName)
        {
            if (_accounts.Any(a => a.Email.Equals(email, StringComparison.OrdinalIgnoreCase)))
            {
                throw new InvalidOperationException("Пользователь с таким email уже существует");
            }

            var account = new UserAccount
            {
                Email = email.Trim(),
                FullName = string.IsNullOrWhiteSpace(fullName) ? "Гость" : fullName.Trim(),
                PasswordHash = PasswordHasher.Hash(password)
            };

            _accounts.Add(account);
            Save();
            return account;
        }

        public UserAccount Login(string email, string password)
        {
            var account = _accounts.FirstOrDefault(a =>
                a.Email.Equals(email, StringComparison.OrdinalIgnoreCase));

            if (account == null || !PasswordHasher.Verify(password, account.PasswordHash))
            {
                throw new InvalidOperationException("Неверный email или пароль");
            }

            return account;
        }

        private void Load()
        {
            if (!File.Exists(_storePath))
            {
                return;
            }

            var json = File.ReadAllText(_storePath);
            var data = JsonSerializer.Deserialize<List<UserAccount>>(json);
            if (data != null)
            {
                _accounts.Clear();
                _accounts.AddRange(data);
            }
        }

        private void Save()
        {
            var json = JsonSerializer.Serialize(_accounts, new JsonSerializerOptions
            {
                WriteIndented = true
            });
            File.WriteAllText(_storePath, json);
        }

        private void EnsureAdminAccount()
        {
            if (_accounts.Any(a => a.Email.Equals(AdminEmail, StringComparison.OrdinalIgnoreCase)))
            {
                return;
            }

            _accounts.Add(new UserAccount
            {
                Email = AdminEmail,
                FullName = "Администратор",
                PasswordHash = PasswordHasher.Hash(AdminPassword)
            });

            Save();
        }
    }
}

