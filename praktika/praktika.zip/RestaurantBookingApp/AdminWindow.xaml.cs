using System.Windows;
using RestaurantBookingApp.ViewModels;

namespace RestaurantBookingApp;

public partial class AdminWindow : Window
{
    public AdminWindow()
    {
        InitializeComponent();
        DataContext = new AdminViewModel();
    }

    private void LogoutButton_OnClick(object sender, RoutedEventArgs e)
    {
        App.StartSession(this);
    }
}

