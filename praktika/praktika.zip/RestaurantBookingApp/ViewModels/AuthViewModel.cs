using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using RestaurantBookingApp.Models;
using RestaurantBookingApp.Services;
using RestaurantBookingApp.Utilities;

namespace RestaurantBookingApp.ViewModels
{
    /// <summary>
    /// VM экрана авторизации/регистрации.
    /// </summary>
    public class AuthViewModel : INotifyPropertyChanged
    {
        private readonly AuthService _authService = new();
        private string _email = string.Empty;
        private string _password = string.Empty;
        private string _fullName = string.Empty;
        private bool _isRegisterMode;
        private string _status = "Введите email и пароль";
        private bool _isBusy;

        public event PropertyChangedEventHandler? PropertyChanged;
        public event Action<UserProfile>? Authenticated;

        public AuthViewModel()
        {
            ToggleModeCommand = new RelayCommand(_ => ToggleMode());
            SubmitCommand = new RelayCommand(_ => Submit(), _ => !IsBusy);
        }

        public string Email
        {
            get => _email;
            set
            {
                _email = value;
                OnPropertyChanged();
            }
        }

        public string Password
        {
            get => _password;
            set
            {
                _password = value;
                OnPropertyChanged();
            }
        }

        public string FullName
        {
            get => _fullName;
            set
            {
                _fullName = value;
                OnPropertyChanged();
            }
        }

        public bool IsRegisterMode
        {
            get => _isRegisterMode;
            set
            {
                _isRegisterMode = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(SubmitButtonText));
                StatusMessage = IsRegisterMode
                    ? "Заполните email, пароль и имя"
                    : "Введите email и пароль";
            }
        }

        public string SubmitButtonText => IsRegisterMode ? "Зарегистрироваться" : "Войти";

        public string StatusMessage
        {
            get => _status;
            set
            {
                _status = value;
                OnPropertyChanged();
            }
        }

        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                _isBusy = value;
                OnPropertyChanged();
                (SubmitCommand as RelayCommand)?.RaiseCanExecuteChanged();
            }
        }

        public ICommand ToggleModeCommand { get; }
        public ICommand SubmitCommand { get; }

        private void ToggleMode()
        {
            IsRegisterMode = !IsRegisterMode;
        }

        private void Submit()
        {
            try
            {
                IsBusy = true;
                if (IsRegisterMode)
                {
                    if (string.IsNullOrWhiteSpace(FullName))
                    {
                        throw new InvalidOperationException("Укажите имя");
                    }

                    var account = _authService.Register(Email, Password, FullName);
                    StatusMessage = "Регистрация успешна. Можно входить.";
                    IsRegisterMode = false;
                    Email = account.Email;
                    FullName = account.FullName;
                    Password = string.Empty;
                    return;
                }

                var user = _authService.Login(Email, Password);
                var profile = new UserProfile
                {
                    Email = user.Email,
                    FullName = user.FullName,
                    IsAdmin = user.Email.Equals(AuthService.AdminEmail, StringComparison.OrdinalIgnoreCase)
                };

                Authenticated?.Invoke(profile);
            }
            catch (Exception ex)
            {
                StatusMessage = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }

        private void OnPropertyChanged([CallerMemberName] string? name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}

