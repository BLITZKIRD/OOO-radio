using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using RestaurantBookingApp.Data;
using RestaurantBookingApp.Models;
using RestaurantBookingApp.Utilities;

namespace RestaurantBookingApp.ViewModels
{
    /// <summary>
    /// Управление заявками для администратора.
    /// </summary>
    public class AdminViewModel : INotifyPropertyChanged
    {
        private readonly ReservationRepository _repository = new();
        private ReservationRecord? _selectedReservation;

        public AdminViewModel()
        {
            RefreshCommand = new RelayCommand(_ => LoadReservations());
            ApproveCommand = new RelayCommand(_ => UpdateStatus("Подтверждена"), _ => SelectedReservation != null);
            CancelCommand = new RelayCommand(_ => UpdateStatus("Отменена"), _ => SelectedReservation != null);
            DeleteCommand = new RelayCommand(_ => DeleteSelected(), _ => SelectedReservation != null);
            LoadReservations();
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public ObservableCollection<ReservationRecord> Reservations { get; } = new();

        public ReservationRecord? SelectedReservation
        {
            get => _selectedReservation;
            set
            {
                _selectedReservation = value;
                OnPropertyChanged();
                (ApproveCommand as RelayCommand)?.RaiseCanExecuteChanged();
                (CancelCommand as RelayCommand)?.RaiseCanExecuteChanged();
                (DeleteCommand as RelayCommand)?.RaiseCanExecuteChanged();
            }
        }

        public ICommand RefreshCommand { get; }
        public ICommand ApproveCommand { get; }
        public ICommand CancelCommand { get; }
        public ICommand DeleteCommand { get; }

        private void LoadReservations()
        {
            Reservations.Clear();
            foreach (var record in _repository.GetAll())
            {
                Reservations.Add(record);
            }
        }

        private void UpdateStatus(string status)
        {
            if (SelectedReservation == null)
            {
                return;
            }

            _repository.UpdateStatus(SelectedReservation.Id, status);
            LoadReservations();
        }

        private void DeleteSelected()
        {
            if (SelectedReservation == null)
            {
                return;
            }

            _repository.Delete(SelectedReservation.Id);
            LoadReservations();
        }

        private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

