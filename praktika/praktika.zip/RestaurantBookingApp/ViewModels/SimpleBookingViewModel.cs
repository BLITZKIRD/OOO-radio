using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using RestaurantBookingApp.Data;
using RestaurantBookingApp.Models;
using RestaurantBookingApp.Utilities;

namespace RestaurantBookingApp.ViewModels
{
    /// <summary>
    /// Простая VM для бронирования столика в одном ресторане.
    /// </summary>
    public class SimpleBookingViewModel : INotifyPropertyChanged
    {
        private readonly ReservationRepository _repository = new();
        private readonly ObservableCollection<string> _reservationHistory = new();
        private readonly ObservableCollection<TableSeat> _tables = new();
        private DateTime _selectedDate = DateTime.Today.AddDays(1);
        private string _selectedTime = "19:00";
        private int _guestCount = 2;
        private string _specialRequest = string.Empty;
        private string _statusMessage = "Выберите дату и время, затем нажмите «Забронировать»";
        private TableSeat? _selectedTable;

        public SimpleBookingViewModel(UserProfile? profile = null)
        {
            CurrentUser = profile ?? new UserProfile();
            RestaurantName = "NeoReserve Chef's Table";
            RestaurantDescription = "Авторская кухня, 8 фирменных сетов и уютная атмосфера.";
            RestaurantAddress = "Москва, ул. Гастрономическая, 12";
            RestaurantPhone = "+7 (495) 123-45-67";

            AvailableTimes = new ObservableCollection<string>
            {
                "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00"
            };

            BuildTables();
            SubmitReservationCommand = new RelayCommand(_ => SubmitReservation(), _ => CanSubmit());
            LoadUserReservations();
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public UserProfile CurrentUser { get; }

        public string UserGreeting => $"Здравствуйте, {CurrentUser.FullName}!";

        public string RestaurantName { get; }
        public string RestaurantDescription { get; }
        public string RestaurantAddress { get; }
        public string RestaurantPhone { get; }

        public ObservableCollection<string> AvailableTimes { get; }
        public ObservableCollection<string> ReservationHistory => _reservationHistory;
        public ObservableCollection<TableSeat> Tables => _tables;

        public DateTime SelectedDate
        {
            get => _selectedDate;
            set
            {
                _selectedDate = value;
                OnPropertyChanged();
            }
        }

        public string SelectedTime
        {
            get => _selectedTime;
            set
            {
                _selectedTime = value;
                OnPropertyChanged();
            }
        }

        public int GuestCount
        {
            get => _guestCount;
            set
            {
                _guestCount = value;
                OnPropertyChanged();
            }
        }

        public string SpecialRequest
        {
            get => _specialRequest;
            set
            {
                _specialRequest = value;
                OnPropertyChanged();
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set
            {
                _statusMessage = value;
                OnPropertyChanged();
            }
        }

        public TableSeat? SelectedTable
        {
            get => _selectedTable;
            set
            {
                _selectedTable = value;
                OnPropertyChanged();
                (SubmitReservationCommand as RelayCommand)?.RaiseCanExecuteChanged();
            }
        }

        public ICommand SubmitReservationCommand { get; }

        private bool CanSubmit()
        {
            return SelectedDate >= DateTime.Today
                   && !string.IsNullOrWhiteSpace(SelectedTime)
                   && SelectedTable != null;
        }

        private void SubmitReservation()
        {
            if (SelectedTable == null)
            {
                StatusMessage = "Выберите столик на схеме.";
                return;
            }

            var record = new ReservationRecord
            {
                CustomerName = CurrentUser.FullName,
                CustomerEmail = CurrentUser.Email,
                ReservationDate = SelectedDate,
                ReservationTime = SelectedTime,
                Guests = GuestCount,
                SpecialRequest = $"Столик #{SelectedTable.Number} ({SelectedTable.Type}). {SpecialRequest}",
                Status = "Новая",
                CreatedAt = DateTime.UtcNow
            };

            _repository.AddReservation(record);
            LoadUserReservations();
            StatusMessage = "Бронь сохранена в системе. Ожидайте подтверждение администратора.";
            SpecialRequest = string.Empty;
            SelectedTable = null;
        }

        private void LoadUserReservations()
        {
            ReservationHistory.Clear();
            if (string.IsNullOrWhiteSpace(CurrentUser.Email))
            {
                return;
            }

            foreach (var record in _repository.GetByEmail(CurrentUser.Email))
            {
                var text = $"{record.ReservationDate:dd MMM} • {record.ReservationTime} • {record.Guests} гостей • Статус: {record.Status}";
                if (!string.IsNullOrWhiteSpace(record.SpecialRequest))
                {
                    text += $" • {record.SpecialRequest}";
                }

                ReservationHistory.Add(text);
            }
        }

        private void BuildTables()
        {
            _tables.Clear();
            for (var i = 1; i <= 12; i++)
            {
                _tables.Add(new TableSeat
                {
                    Number = i,
                    Capacity = i % 3 == 0 ? 4 : 2,
                    Type = i % 2 == 0 ? "У окна" : "Зал",
                    IsAvailable = true
                });
            }
        }

        private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

