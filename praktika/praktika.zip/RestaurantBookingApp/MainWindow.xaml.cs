using System;
using System.Windows;
using RestaurantBookingApp.ViewModels;

namespace RestaurantBookingApp;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow(Models.UserProfile? profile = null)
    {
        InitializeComponent();
        DataContext = new SimpleBookingViewModel(profile);
    }

    private void LogoutButton_OnClick(object sender, RoutedEventArgs e)
    {
        App.StartSession(this);
    }
}