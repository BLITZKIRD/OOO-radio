# Скрипт для тестирования запуска приложения
Write-Host "Завершение старых процессов..."
Get-Process -Name RestaurantBookingApp -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2

Write-Host "Сборка проекта..."
Set-Location -Path $PSScriptRoot
dotnet build

if ($LASTEXITCODE -eq 0) {
    Write-Host "Запуск приложения..."
    dotnet run
} else {
    Write-Host "Ошибка сборки!"
}

