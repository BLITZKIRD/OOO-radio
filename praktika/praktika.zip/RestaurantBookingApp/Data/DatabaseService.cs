using Microsoft.Data.Sqlite;
using System.IO;

namespace RestaurantBookingApp.Data
{
    /// <summary>
    /// Отвечает за создание и инициализацию SQLite базы.
    /// </summary>
    public class DatabaseService
    {
        public static DatabaseService Instance { get; } = new();

        public string DatabasePath { get; }
        public string ConnectionString => $"Data Source={DatabasePath}";

        private DatabaseService()
        {
            DatabasePath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "NeoReserve",
                "neoreserve.db");

            Directory.CreateDirectory(Path.GetDirectoryName(DatabasePath)!);
            EnsureCreated();
            Seed();
        }

        private void EnsureCreated()
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();

            var command = connection.CreateCommand();
            command.CommandText =
                """
                CREATE TABLE IF NOT EXISTS Reservations
                (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    CustomerName TEXT NOT NULL,
                    CustomerEmail TEXT NOT NULL,
                    ReservationDate TEXT NOT NULL,
                    ReservationTime TEXT NOT NULL,
                    Guests INTEGER NOT NULL,
                    SpecialRequest TEXT,
                    Status TEXT NOT NULL,
                    CreatedAt TEXT NOT NULL
                );
                """;
            command.ExecuteNonQuery();
        }

        private void Seed()
        {
            using var connection = new SqliteConnection(ConnectionString);
            connection.Open();

            var countCmd = connection.CreateCommand();
            countCmd.CommandText = "SELECT COUNT(*) FROM Reservations";
            var count = Convert.ToInt32(countCmd.ExecuteScalar());
            if (count > 0)
            {
                return;
            }

            var samples = new[]
            {
                ("Анна", "anna@example.com", DateTime.Today.AddDays(1), "18:00", 2, "Годовщина свадьбы", "Новая"),
                ("Максим", "max@example.com", DateTime.Today.AddDays(2), "20:30", 4, "Сделать тише музыку", "Подтверждена"),
                ("Сергей", "sergey@example.com", DateTime.Today.AddDays(3), "19:15", 3, "", "Отменена")
            };

            foreach (var sample in samples)
            {
                var insert = connection.CreateCommand();
                insert.CommandText =
                    """
                    INSERT INTO Reservations
                    (CustomerName, CustomerEmail, ReservationDate, ReservationTime, Guests, SpecialRequest, Status, CreatedAt)
                    VALUES ($name, $email, $date, $time, $guests, $request, $status, $created);
                    """;
                insert.Parameters.AddWithValue("$name", sample.Item1);
                insert.Parameters.AddWithValue("$email", sample.Item2);
                insert.Parameters.AddWithValue("$date", sample.Item3.ToString("yyyy-MM-dd"));
                insert.Parameters.AddWithValue("$time", sample.Item4);
                insert.Parameters.AddWithValue("$guests", sample.Item5);
                insert.Parameters.AddWithValue("$request", sample.Item6);
                insert.Parameters.AddWithValue("$status", sample.Item7);
                insert.Parameters.AddWithValue("$created", DateTime.UtcNow.ToString("o"));
                insert.ExecuteNonQuery();
            }
        }
    }
}

