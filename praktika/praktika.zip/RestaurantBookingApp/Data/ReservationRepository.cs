using Microsoft.Data.Sqlite;
using RestaurantBookingApp.Models;

namespace RestaurantBookingApp.Data
{
    public class ReservationRepository
    {
        private readonly DatabaseService _database = DatabaseService.Instance;

        public void AddReservation(ReservationRecord record)
        {
            using var connection = new SqliteConnection(_database.ConnectionString);
            connection.Open();

            var cmd = connection.CreateCommand();
            cmd.CommandText =
                """
                INSERT INTO Reservations
                (CustomerName, CustomerEmail, ReservationDate, ReservationTime, Guests, SpecialRequest, Status, CreatedAt)
                VALUES ($name, $email, $date, $time, $guests, $request, $status, $created);
                """;
            cmd.Parameters.AddWithValue("$name", record.CustomerName);
            cmd.Parameters.AddWithValue("$email", record.CustomerEmail);
            cmd.Parameters.AddWithValue("$date", record.ReservationDate.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("$time", record.ReservationTime);
            cmd.Parameters.AddWithValue("$guests", record.Guests);
            cmd.Parameters.AddWithValue("$request", record.SpecialRequest);
            cmd.Parameters.AddWithValue("$status", record.Status);
            cmd.Parameters.AddWithValue("$created", record.CreatedAt.ToString("o"));
            cmd.ExecuteNonQuery();
        }

        public IReadOnlyList<ReservationRecord> GetByEmail(string email)
        {
            using var connection = new SqliteConnection(_database.ConnectionString);
            connection.Open();

            var cmd = connection.CreateCommand();
            cmd.CommandText =
                """
                SELECT Id, CustomerName, CustomerEmail, ReservationDate, ReservationTime,
                       Guests, SpecialRequest, Status, CreatedAt
                FROM Reservations
                WHERE CustomerEmail = $email
                ORDER BY ReservationDate DESC, ReservationTime DESC;
                """;
            cmd.Parameters.AddWithValue("$email", email);

            return ReadReservations(cmd);
        }

        public IReadOnlyList<ReservationRecord> GetAll()
        {
            using var connection = new SqliteConnection(_database.ConnectionString);
            connection.Open();

            var cmd = connection.CreateCommand();
            cmd.CommandText =
                """
                SELECT Id, CustomerName, CustomerEmail, ReservationDate, ReservationTime,
                       Guests, SpecialRequest, Status, CreatedAt
                FROM Reservations
                ORDER BY ReservationDate DESC, ReservationTime DESC;
                """;

            return ReadReservations(cmd);
        }

        public void UpdateStatus(int id, string status)
        {
            using var connection = new SqliteConnection(_database.ConnectionString);
            connection.Open();

            var cmd = connection.CreateCommand();
            cmd.CommandText = "UPDATE Reservations SET Status = $status WHERE Id = $id";
            cmd.Parameters.AddWithValue("$status", status);
            cmd.Parameters.AddWithValue("$id", id);
            cmd.ExecuteNonQuery();
        }

        public void Delete(int id)
        {
            using var connection = new SqliteConnection(_database.ConnectionString);
            connection.Open();

            var cmd = connection.CreateCommand();
            cmd.CommandText = "DELETE FROM Reservations WHERE Id = $id";
            cmd.Parameters.AddWithValue("$id", id);
            cmd.ExecuteNonQuery();
        }

        private static List<ReservationRecord> ReadReservations(SqliteCommand command)
        {
            var list = new List<ReservationRecord>();
            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new ReservationRecord
                {
                    Id = reader.GetInt32(0),
                    CustomerName = reader.GetString(1),
                    CustomerEmail = reader.GetString(2),
                    ReservationDate = DateTime.Parse(reader.GetString(3)),
                    ReservationTime = reader.GetString(4),
                    Guests = reader.GetInt32(5),
                    SpecialRequest = reader.IsDBNull(6) ? string.Empty : reader.GetString(6),
                    Status = reader.GetString(7),
                    CreatedAt = DateTime.Parse(reader.GetString(8))
                });
            }

            return list;
        }
    }
}

