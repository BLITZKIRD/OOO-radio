using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace RestaurantBookingApp.Converters
{
    /// <summary>
    /// Конвертер подсвечивает свободные и занятые столики разными цветами.
    /// </summary>
    public class AvailabilityToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value is bool isAvailable && isAvailable
                ? Application.Current.FindResource("Brush.Success") as Brush ?? Brushes.SeaGreen
                : Application.Current.FindResource("Brush.Danger") as Brush ?? Brushes.IndianRed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException("Обратное преобразование не требуется.");
        }
    }
}

