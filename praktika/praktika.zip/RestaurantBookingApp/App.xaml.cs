using System;
using System.Windows;
using System.Windows.Threading;

namespace RestaurantBookingApp;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
    /// <summary>
    /// Обработчик необработанных исключений для отладки.
    /// </summary>
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        // Обработка необработанных исключений
        DispatcherUnhandledException += App_DispatcherUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;

        StartSession();
    }

    /// <summary>
    /// Обработчик исключений в UI потоке.
    /// </summary>
    private void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        MessageBox.Show($"Ошибка: {e.Exception.Message}\n\n{e.Exception.StackTrace}", 
            "Ошибка приложения", MessageBoxButton.OK, MessageBoxImage.Error);
        e.Handled = true;
    }

    /// <summary>
    /// Обработчик критических исключений.
    /// </summary>
    private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
    {
        if (e.ExceptionObject is Exception ex)
        {
            MessageBox.Show($"Критическая ошибка: {ex.Message}\n\n{ex.StackTrace}", 
                "Критическая ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    /// <summary>
    /// Показывает окно авторизации и запускает подходящее окно.
    /// </summary>
    public static void StartSession(Window? previousWindow = null)
    {
        Current.ShutdownMode = ShutdownMode.OnExplicitShutdown;
        var authWindow = new AuthWindow();
        if (authWindow.ShowDialog() == true && authWindow.AuthenticatedProfile is Models.UserProfile profile)
        {
            try
            {
                Window window = profile.IsAdmin ? new AdminWindow() : new MainWindow(profile);
                Current.MainWindow = window;
                Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
                window.Show();
                previousWindow?.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании окна: {ex.Message}\n\n{ex.StackTrace}",
                    "Критическая ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                previousWindow?.Close();
                Current.Shutdown();
            }
        }
        else
        {
            previousWindow?.Close();
            Current.Shutdown();
        }
    }
}

