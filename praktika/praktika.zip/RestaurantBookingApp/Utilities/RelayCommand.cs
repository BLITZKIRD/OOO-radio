using System;
using System.Windows.Input;

namespace RestaurantBookingApp.Utilities
{
    /// <summary>
    /// Простой ICommand для биндинга кнопок к методам ViewModel.
    /// </summary>
    public class RelayCommand : ICommand
    {
        private readonly Action<object?> _execute;
        private readonly Predicate<object?>? _canExecute;

        /// <summary>
        /// Создаёт команду с обязательным делегатом выполнения.
        /// </summary>
        public RelayCommand(Action<object?> execute, Predicate<object?>? canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        /// <summary>
        /// Событие для уведомления UI о смене доступности.
        /// </summary>
        public event EventHandler? CanExecuteChanged;

        /// <summary>
        /// Проверяет, можно ли запускать команду.
        /// </summary>
        public bool CanExecute(object? parameter) => _canExecute?.Invoke(parameter) ?? true;

        /// <summary>
        /// Выполняет привязанный делегат.
        /// </summary>
        public void Execute(object? parameter) => _execute(parameter);

        /// <summary>
        /// Принудительно сообщает об изменении CanExecute.
        /// </summary>
        public void RaiseCanExecuteChanged() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
    }
}

