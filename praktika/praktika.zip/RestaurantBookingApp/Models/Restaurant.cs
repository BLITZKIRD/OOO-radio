using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace RestaurantBookingApp.Models
{
    /// <summary>
    /// Описывает карточку ресторана с меню, столиками и отзывами.
    /// </summary>
    public class Restaurant
    {
        /// <summary>
        /// Название ресторана.
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Тип кухни для фильтрации.
        /// </summary>
        public string Cuisine { get; set; } = string.Empty;

        /// <summary>
        /// Географическая зона или район.
        /// </summary>
        public string Location { get; set; } = string.Empty;

        /// <summary>
        /// Средний чек (бюджетный, средний, высокий).
        /// </summary>
        public string AverageCheckTier { get; set; } = "Средний";

        /// <summary>
        /// Средняя пользовательская оценка.
        /// </summary>
        public double Rating { get; set; }

        /// <summary>
        /// Пути к изображениям для мини-галереи.
        /// </summary>
        public List<string> Gallery { get; set; } = new();

        /// <summary>
        /// Ключевые особенности (живая музыка, Wi-Fi и т. п.).
        /// </summary>
        public List<string> Features { get; set; } = new();

        /// <summary>
        /// Меню, доступное для предзаказа.
        /// </summary>
        public ObservableCollection<MenuItem> Menu { get; set; } = new();

        /// <summary>
        /// Список отзывов пользователей.
        /// </summary>
        public ObservableCollection<Review> Reviews { get; set; } = new();

        /// <summary>
        /// Карта столиков для интерактивного выбора.
        /// </summary>
        public ObservableCollection<TableSeat> Tables { get; set; } = new();

        /// <summary>
        /// Описание уникальных правил и политики.
        /// </summary>
        public string Description { get; set; } = string.Empty;

        /// <summary>
        /// Контакты (телефон, сайт, соцсети).
        /// </summary>
        public string Contacts { get; set; } = string.Empty;

        /// <summary>
        /// Режим работы и технологические перерывы.
        /// </summary>
        public string WorkingHours { get; set; } = "Ежедневно 10:00-23:00";
    }
}

