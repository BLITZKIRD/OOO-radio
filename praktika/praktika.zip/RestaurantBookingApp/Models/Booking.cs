using System;

namespace RestaurantBookingApp.Models
{
    /// <summary>
    /// Бронь столика с полной информацией для обеих сторон.
    /// </summary>
    public class Booking
    {
        /// <summary>
        /// Уникальный идентификатор брони для работы с CRM.
        /// </summary>
        public Guid Id { get; set; } = Guid.NewGuid();

        /// <summary>
        /// Ссылка на ресторан, в котором создана бронь.
        /// </summary>
        public Restaurant? Restaurant { get; set; }

        /// <summary>
        /// Выбранный столик.
        /// </summary>
        public TableSeat? Table { get; set; }

        /// <summary>
        /// Дата и время визита.
        /// </summary>
        public DateTime VisitDate { get; set; } = DateTime.Now.AddDays(1);

        /// <summary>
        /// Количество гостей.
        /// </summary>
        public int Guests { get; set; } = 2;

        /// <summary>
        /// Текущий статус (ожидание, подтверждено, отменено).
        /// </summary>
        public string Status { get; set; } = "Ожидает подтверждения";

        /// <summary>
        /// Особые пожелания или комментарии.
        /// </summary>
        public string SpecialRequest { get; set; } = string.Empty;

        /// <summary>
        /// Требуется ли подтверждение со стороны гостя.
        /// </summary>
        public bool AwaitingClientConfirmation { get; set; }

        /// <summary>
        /// Пометка о внесении депозита или полной оплаты.
        /// </summary>
        public bool DepositPaid { get; set; }

        /// <summary>
        /// Есть ли предзаказ блюд.
        /// </summary>
        public bool HasPreOrder { get; set; }
    }
}

