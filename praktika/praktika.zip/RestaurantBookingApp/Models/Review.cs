using System;

namespace RestaurantBookingApp.Models
{
    /// <summary>
    /// Пользовательский отзыв о ресторане.
    /// </summary>
    public class Review
    {
        /// <summary>
        /// Имя автора или псевдоним.
        /// </summary>
        public string Author { get; set; } = string.Empty;

        /// <summary>
        /// Оценка по пятибалльной шкале.
        /// </summary>
        public double Score { get; set; }

        /// <summary>
        /// Текст комментария.
        /// </summary>
        public string Comment { get; set; } = string.Empty;

        /// <summary>
        /// Дата визита, чтобы анализировать актуальность отзывов.
        /// </summary>
        public DateTime Date { get; set; } = DateTime.Today;
    }
}

