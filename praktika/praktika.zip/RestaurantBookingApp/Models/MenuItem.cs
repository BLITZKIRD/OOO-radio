namespace RestaurantBookingApp.Models
{
    /// <summary>
    /// Строка меню с ценой и дополнительными характеристиками.
    /// </summary>
    public class MenuItem
    {
        /// <summary>
        /// Название блюда или напитка.
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Категория (салаты, горячее, десерты, напитки и т. п.).
        /// </summary>
        public string Category { get; set; } = string.Empty;

        /// <summary>
        /// Стоимость в базовой валюте.
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// Признак того, что блюдо подходит веганам.
        /// </summary>
        public bool IsVegan { get; set; }

        /// <summary>
        /// Указание на необходимость предзаказа (например, сложные блюда).
        /// </summary>
        public bool RequiresPreOrder { get; set; }
    }
}

