using System;
using System.Collections.ObjectModel;

namespace RestaurantBookingApp.Models
{
    /// <summary>
    /// Представляет профиль гостя и его индивидуальные настройки.
    /// </summary>
    public class UserProfile
    {
        /// <summary>
        /// Имя гостя, используемое в бронированиях и приветствиях.
        /// </summary>
        public string FullName { get; set; } = "Гость";

        /// <summary>
        /// Email для регистрации и уведомлений.
        /// </summary>
        public string Email { get; set; } = "guest@example.com";

        /// <summary>
        /// Номер телефона для SMS и подтверждений.
        /// </summary>
        public string Phone { get; set; } = "+7 (900) 000-00-00";

        /// <summary>
        /// Предпочтительная кухня, чтобы ускорить подбор ресторанов.
        /// </summary>
        public string PreferredCuisine { get; set; } = "Итальянская";

        /// <summary>
        /// Предпочтительный тип столика (окно, терраса, VIP и т. д.).
        /// </summary>
        public string PreferredSeating { get; set; } = "У окна";

        /// <summary>
        /// Дополнительные заметки (аллергии, праздники, важные даты).
        /// </summary>
        public string AdditionalNotes { get; set; } = "Аллергия на орехи";

        /// <summary>
        /// Флаг согласия на пуш/SMS уведомления.
        /// </summary>
        public bool AllowNotifications { get; set; } = true;

        /// <summary>
        /// Дата рождения для расчёта персональных бонусов.
        /// </summary>
        public DateTime? Birthday { get; set; } = DateTime.Today.AddYears(-25);

        /// <summary>
        /// История всех прошлых бронирований пользователя.
        /// </summary>
        public ObservableCollection<Booking> BookingHistory { get; set; } = new();

        /// <summary>
        /// Список избранных ресторанов для быстрого доступа.
        /// </summary>
        public ObservableCollection<Restaurant> Favorites { get; set; } = new();

        /// <summary>
        /// Признак, что пользователь — администратор.
        /// </summary>
        public bool IsAdmin { get; set; }
    }
}

