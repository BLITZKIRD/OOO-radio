namespace RestaurantBookingApp.Models
{
    /// <summary>
    /// DTO для хранения записей бронирования в базе.
    /// </summary>
    public class ReservationRecord
    {
        public int Id { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public string CustomerEmail { get; set; } = string.Empty;
        public DateTime ReservationDate { get; set; }
        public string ReservationTime { get; set; } = string.Empty;
        public int Guests { get; set; }
        public string SpecialRequest { get; set; } = string.Empty;
        public string Status { get; set; } = "Новая";
        public DateTime CreatedAt { get; set; }
    }
}

