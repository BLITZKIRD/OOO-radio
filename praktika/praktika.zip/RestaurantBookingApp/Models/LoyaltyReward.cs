namespace RestaurantBookingApp.Models
{
    /// <summary>
    /// Описывает бонусную механику в системе лояльности.
    /// </summary>
    public class LoyaltyReward
    {
        /// <summary>
        /// Короткое название награды.
        /// </summary>
        public string Title { get; set; } = string.Empty;

        /// <summary>
        /// Детальное описание условия получения.
        /// </summary>
        public string Description { get; set; } = string.Empty;

        /// <summary>
        /// Текущее состояние выполнения (например, 3 из 5).
        /// </summary>
        public int Progress { get; set; }

        /// <summary>
        /// Требуемое количество действий до выдачи приза.
        /// </summary>
        public int Threshold { get; set; } = 5;

        /// <summary>
        /// Партнёр, у которого можно потратить баллы.
        /// </summary>
        public string Partner { get; set; } = "Любые рестораны сети";
    }
}

