using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace RestaurantBookingApp.Models
{
    /// <summary>
    /// Описывает конкретный столик и его состояние на схеме.
    /// </summary>
    public class TableSeat : INotifyPropertyChanged
    {
        private bool _isAvailable;
        private bool _requiresDeposit;

        /// <summary>
        /// Номер столика для визуальной идентификации.
        /// </summary>
        public int Number { get; set; }

        /// <summary>
        /// Тип столика (терраса, окно, VIP и т. д.).
        /// </summary>
        public string Type { get; set; } = "Стандарт";

        /// <summary>
        /// Максимальная вместимость столика.
        /// </summary>
        public int Capacity { get; set; }

        /// <summary>
        /// Признак доступности столика в выбранное время.
        /// </summary>
        public bool IsAvailable
        {
            get => _isAvailable;
            set
            {
                if (_isAvailable == value)
                {
                    return;
                }

                _isAvailable = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// Требуется ли депозит при бронировании данного места.
        /// </summary>
        public bool RequiresDeposit
        {
            get => _requiresDeposit;
            set
            {
                if (_requiresDeposit == value)
                {
                    return;
                }

                _requiresDeposit = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// Событие для уведомления UI об изменении свойств.
        /// </summary>
        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

