namespace RestaurantBookingApp.Models
{
    /// <summary>
    /// Минимальный аккаунт для авторизации по email и паролю.
    /// </summary>
    public class UserAccount
    {
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string FullName { get; set; } = "Гость";
    }
}

